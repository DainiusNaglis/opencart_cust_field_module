<?php
// Heading
$_['heading_title']                     = 'Atsijungimas';

// Text
$_['text_message']                      = '<p>Jūs atjungtas iš savo paskyros. Dabar saugu palikti kompiuterį.</p><p>Jūsų pirkinių krepšelis buvo išsaugotas, prekės esančios krepšelyje bus atkurtos, kai jūs prisijungsite atgal į savo paskyrą.</p>';
$_['text_account']                      = 'Paskyra';
$_['text_logout']                       = 'Atsijungti';
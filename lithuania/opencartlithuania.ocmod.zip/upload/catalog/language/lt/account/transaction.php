<?php
// Heading
$_['heading_title']                     = 'Sandoriai';

// Column
$_['column_date_added']                 = 'Data';
$_['column_description']                = 'Aprašymas';
$_['column_amount']                     = 'Kiekis (%s)';

// Text
$_['text_account']                      = 'Paskyra';
$_['text_transaction']                  = 'Sandoriai';
$_['text_total']                        = 'Jūsų dabartinis balansas yra:';
$_['text_empty']                        = 'Neturite sandorių!';
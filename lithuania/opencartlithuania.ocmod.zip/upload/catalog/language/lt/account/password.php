<?php
// Heading
$_['heading_title']                     = 'Keisti slaptažodį';

// Text
$_['text_account']                      = 'Paskyra';
$_['text_password']                     = 'Jūsų slaptažodis';
$_['text_success']                      = 'Sėkmingai atnaujintas slaptažodis.';

// Entry
$_['entry_password']                    = 'Slaptažodis';
$_['entry_confirm']                     = 'Patvirtinkite slaptažodį';

// Error
$_['error_password']                    = 'Slaptažodis turi būti nuo 4 iki 20 simbolių ilgio!';
$_['error_confirm']                     = 'Slaptažodžio patvirtinimas nesutampa su įvestu slaptažodžiu!';
<?php
// Heading
$_['heading_title']                     = 'Paskyros atsisiuntimai';

// Text
$_['text_account']                      = 'Paskyra';
$_['text_downloads']                    = 'Atsisiuntimai';
$_['text_empty']                        = 'Jūs neturite ankstesnių atsisiunčiamų užsakymų!';

// Column
$_['column_order_id']                   = 'Užsakymo nr.';
$_['column_name']                       = 'Pavadinimas';
$_['column_size']                       = 'Dydis';
$_['column_date_added']                 = 'Data';
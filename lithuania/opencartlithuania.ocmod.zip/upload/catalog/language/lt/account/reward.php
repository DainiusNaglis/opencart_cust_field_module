<?php
// Heading
$_['heading_title']                     = 'Jūsų lojalumo taškai';

// Column
$_['column_date_added']                 = 'Data';
$_['column_description']                = 'Aprašymas';
$_['column_points']                     = 'Taškai';

// Text
$_['text_account']                      = 'Paskyra';
$_['text_reward']                       = 'Lojalumo taškai';
$_['text_total']                        = 'Sukaupta lojalumo taškų:';
$_['text_empty']                        = 'Neturite lojalumo taškų!';
<?php
// Text
$_['text_upload']                       = 'Jūsų rinkmena sėkmingai įkelta!';

// Error
$_['error_filename']                    = 'Rinkmenos vardas turi būti nuo 3 iki 64 simbolių!';
$_['error_filetype']                    = 'Netinkamas rinkmenos tipas!';
$_['error_upload']                      = 'Nenurodyta įkeliama rinkmena!';
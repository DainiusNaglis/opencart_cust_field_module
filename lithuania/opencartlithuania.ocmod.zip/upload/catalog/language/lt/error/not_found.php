<?php
// Heading
$_['heading_title'] = 'Jūsų ieškomas puslapis negali būti rastas!';

// Text
$_['text_error']    = 'Jūsų ieškomas puslapis negali būti rastas.';
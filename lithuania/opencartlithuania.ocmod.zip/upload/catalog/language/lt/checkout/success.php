<?php
// Heading
$_['heading_title']                     = 'Jūsų užsakymas sėkmingai priimtas!';

// Text
$_['text_basket']                       = 'Krepšelis';
$_['text_checkout']                     = 'Atsiskaitymas';
$_['text_success']                      = 'Pavyko';
$_['text_customer']                     = '<p>Jūsų užsakymas sėkmingai priimtas vykdyti!</p><p>Užsakymų istoriją galite peržiūrėti <a href="%s">prisijungę</a> prie savo paskyros ir nuėję į <a href="%s">užsakymų istorijos</a> puslapį.';
$_['text_guest']                        = '<p>Jūsų užsakymas sėkmingai priimtas vykdyti!</p><p>Jei turite kokių nors klausimų - <a href="%s">susisiekite</a> su mumis.</p><p>Dėkojame, kad perkate pas mus!</p>';

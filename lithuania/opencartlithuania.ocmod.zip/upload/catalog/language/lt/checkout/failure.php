<?php
// Heading
$_['heading_title']                     = 'Apmokėjimas nepavyko!';

// Text
$_['text_basket']                       = 'Krepšelis';
$_['text_checkout']                     = 'Atsiskaitymas';
$_['text_failure']                      = 'Apmokėjimas nepavyko';
$_['text_message']                      = '<p>Iškilo problema apdorojant Jūsų apmokėjimą ir užsakymas nebuvo baigtas</p><p>Galimos priežastys:</p> <ul><li>Nepakanka lėšų</li><li>Nepavyko patvirtinimas</li></ul><p>Prašome bandyti pakartoti užsakymą nurodant kitą mokėjimo būdą.</p><p>Jeigu problema atsikartoja, prašome <a href="%s">kreiptis į mus</a> su detalių užsakymo ir jo eigos aprašymu.</p>';
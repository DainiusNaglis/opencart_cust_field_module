<?php
// Heading
$_['heading_title'] = 'Gyvas pokalbis';
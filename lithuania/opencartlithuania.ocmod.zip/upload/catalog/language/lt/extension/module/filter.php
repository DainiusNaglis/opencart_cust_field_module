<?php
// Heading
$_['heading_title'] = 'Patikslinkite paiešką';
<?php
// Heading
$_['heading_title']                     = 'Pasirinkti parduotuvę';

// Text
$_['text_default']                      = 'Standartinė';
$_['text_store']                        = 'Pasirinkite parduotuvę, kurią norite aplankyti.';
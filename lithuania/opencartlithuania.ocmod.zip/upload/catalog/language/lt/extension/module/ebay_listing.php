<?php
// Heading
$_['heading_title'] = 'Mūsų eBay parduotuvėje';
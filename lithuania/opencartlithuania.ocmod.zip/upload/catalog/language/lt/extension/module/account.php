<?php
// Heading
$_['heading_title']                     = 'Paskyra';

// Text
$_['text_register']                     = 'Registruotis';
$_['text_login']                        = 'Prisijungti';
$_['text_logout']                       = 'Atsijungti';
$_['text_forgotten']                    = 'Pamiršote slaptažodį';
$_['text_account']                      = 'Mano paskyra';
$_['text_edit']                         = 'Redaguoti paskyrą';
$_['text_password']                     = 'Slaptažodis';
$_['text_address']                      = 'Adresų knyga';
$_['text_wishlist']                     = 'Pageidavimų sąrašas';
$_['text_order']                        = 'Užsakymo istorija';
$_['text_download']                     = 'Atsisiuntimai';
$_['text_reward']                       = 'Lojalumo taškai';
$_['text_return']                       = 'Grąžinimo forma';
$_['text_transaction']                  = 'Sandoriai';
$_['text_newsletter']                   = 'Naujienų prenumerata';
$_['text_recurring']                    = 'Periodiniai atsiskaitymai';
<?php
// Heading
$_['heading_title']                     = 'Populiariausios prekės';

// Text
$_['text_tax']                          = 'Be PVM:';
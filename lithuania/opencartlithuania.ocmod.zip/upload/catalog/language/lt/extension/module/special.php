<?php
// Heading
$_['heading_title']                     = 'Akcijos';

// Text
$_['text_tax']                          = 'Be PVM:';
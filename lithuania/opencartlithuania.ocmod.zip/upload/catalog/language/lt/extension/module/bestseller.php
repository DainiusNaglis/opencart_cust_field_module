<?php
// Heading
$_['heading_title']                     = 'Perkamiausios prekės';

// Text
$_['text_tax']                          = 'Be PVM:';
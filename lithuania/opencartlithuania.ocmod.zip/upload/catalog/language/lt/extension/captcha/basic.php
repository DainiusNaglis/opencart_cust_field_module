<?php
// Heading
$_['heading_title']                     = 'Captcha';

// Entry
$_['entry_captcha']                     = 'Įveskite kodą žemiau esančiame laukelyje';

// Error
$_['error_captcha']                     = 'Patvirtinimo kodas nesutampa su paveikslėliu!';
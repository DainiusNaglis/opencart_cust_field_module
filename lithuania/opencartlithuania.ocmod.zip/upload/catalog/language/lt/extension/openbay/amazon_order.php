<?php

// Text
$_['text_paid_amazon']                  = 'Paid on Amazon';
$_['text_total_shipping']               = 'Pristatymas';
$_['text_total_shipping_tax']           = 'Shipping tax';
$_['text_total_giftwrap']               = 'Gift wrap';
$_['text_total_giftwrap_tax']           = 'Gift wrap tax';
$_['text_total_sub']                    = 'Tarpinė suma';
$_['text_tax']                          = 'Mokestis';
$_['text_total']                        = 'Iš viso';
$_['text_gift_message'] 		        = 'Dovanos žinutės';

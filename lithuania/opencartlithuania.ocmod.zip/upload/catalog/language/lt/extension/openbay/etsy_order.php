<?php

// Text
$_['text_total_shipping']               = 'Pristatymas';
$_['text_total_discount']               = 'Nuolaida';
$_['text_total_tax']                    = 'Mokestis';
$_['text_total_sub']                    = 'Tarpinė suma';
$_['text_total']                        = 'Iš viso';
<?php
// Text
$_['text_success']                      = 'Sėkmingai modifikuoti užsakymai!';

// Error
$_['error_permission']                  = 'Įspėjimas: Jūs neturi teisių pasiektii API!';
$_['error_customer']                    = 'Įspėjimas: kliento informacija turi būti nustatyta!';
$_['error_payment_address']             = 'Įspėjimas: apmokėjimo adresas reikalingas!';
$_['error_payment_method']              = 'Įspėjimas: apmokėjimo metodas reikalingas!';
$_['error_no_payment']                  = 'Įspėjimas: apmokėjimo būdų nėra!';
$_['error_shipping_address']            = 'Įspėjimas: pristatymo adresas reikalingas!';
$_['error_shipping_method']             = 'Įspėjimas: pristatymo metodas reikalingas!';
$_['error_no_shipping']                 = 'Įspėjimas: pristatymo būdų nėra!';
$_['error_stock']                       = 'Įspėjimas: prekių pažymėtų su *** likutis yra nepakankamas!';
$_['error_minimum']                     = 'Įspėjimas: minimalus užsakymo %s kiekis yra %s!';
$_['error_not_found']                   = 'Įspėjimas: užsakymas nerastas!';
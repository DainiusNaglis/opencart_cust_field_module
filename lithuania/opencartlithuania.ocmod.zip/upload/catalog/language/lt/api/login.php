<?php
// Text
$_['text_success']                      = 'Sėkmingai pradėta API sesija!';

// Error
$_['error_key']                         = 'Įspėjimas: neteisingas API raktas!';
$_['error_ip']                          = 'Įspėjimas: negalite kreiptis į API iš Jūsų IP adreso!';
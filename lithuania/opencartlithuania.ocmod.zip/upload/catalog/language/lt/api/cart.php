<?php
// Text
$_['text_success']                      = 'Sėkmingai modifikuotas krepšelis!';

// Error
$_['error_permission']                  = 'Įspėjimas: Jūs neturi teisių pasiekti API!';
$_['error_stock']                       = 'Prekių pažymėtų su *** likutis yra nepakankamas!';
$_['error_minimum']                     = 'Minimalus užsakymo %s kiekis yra %s!';
$_['error_store']                       = 'Prekės negali būti perkamos iš pasirinktos parduotuvės!';
$_['error_required']                    = 'Laukas %s yra privalomas!';

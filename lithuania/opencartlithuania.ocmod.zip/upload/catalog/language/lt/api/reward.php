<?php
// Text
$_['text_success']                      = 'Sėkmingai pritaikyta lojalumo taškų nuolaida!';

// Error
$_['error_permission']                  = 'Įspėjimas: Jūs neturi teisių pasiektii API!';
$_['error_reward']                      = 'Įspėjimas: įveskite norimą lojalumo taškų kiekį!';
$_['error_points']                      = 'Įspėjimas: Jūs neturite %s lojalumo taškų!';
$_['error_maximum']                     = 'Įspėjimas: maksimalus taškų kiekis, kurį galite pritaikyti yra %s!';
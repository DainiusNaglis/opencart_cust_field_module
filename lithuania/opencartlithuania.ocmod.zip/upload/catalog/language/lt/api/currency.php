<?php
// Text
$_['text_success']                      = 'Sėkmingai pakeistos valiutos!';

// Error
$_['error_permission']                  = 'Įspėjimas: Jūs neturi teisių pasiektii API!';
$_['error_currency']                    = 'Įspėjimas: valiutos kodas neteisingas!';
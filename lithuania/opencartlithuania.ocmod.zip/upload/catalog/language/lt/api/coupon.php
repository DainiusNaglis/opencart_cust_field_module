<?php
// Text
$_['text_success']                      = 'Sėkmingai pritaikyta kupono nuolaida!';

// Error
$_['error_permission']                  = 'Įspėjimas: Jūs neturi teisių pasiektii API!';
$_['error_coupon']                      = 'Įspėjimas: kuponas arba negaliojantis, pasibaigęs arba panaudotas!';
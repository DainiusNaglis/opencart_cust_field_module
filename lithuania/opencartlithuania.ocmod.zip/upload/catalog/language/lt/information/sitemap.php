<?php
// Heading
$_['heading_title']                     = 'Svetainės žemėlapis';

// Text
$_['text_special']                      = 'Akcijos';
$_['text_account']                      = 'Mano paskyra';
$_['text_edit']                         = 'Paskyros informacija';
$_['text_password']                     = 'Slaptažodis';
$_['text_address']                      = 'Adresų knyga';
$_['text_history']                      = 'Užsakymo istorija';
$_['text_download']                     = 'Atsisiuntimai';
$_['text_cart']                         = 'Krepšelis';
$_['text_checkout']                     = 'Atsiskaitymas';
$_['text_search']                       = 'Paieška';
$_['text_information']                  = 'Informacija';
$_['text_contact']                      = 'Susisiekite su mumis';
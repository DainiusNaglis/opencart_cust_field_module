<?php
// Text
$_['text_error'] = 'Informacinis puslapis nerastas!';
<?php
// Text
$_['text_all'] = 'Rodyti viską';
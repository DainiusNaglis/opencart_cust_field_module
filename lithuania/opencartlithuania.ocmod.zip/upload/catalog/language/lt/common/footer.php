<?php
// Text
$_['text_information']                  = 'Informacija';
$_['text_service']                      = 'Klientų aptarnavimas';
$_['text_extra']                        = 'Priedai';
$_['text_contact']                      = 'Susisiekite su mumis';
$_['text_return']                       = 'Grąžinimo forma';
$_['text_sitemap']                      = 'Svetainės žemėlapis';
$_['text_manufacturer']                 = 'Prekių ženklai';
$_['text_voucher']                      = 'Dovanų kuponai';
$_['text_affiliate']                    = 'Partnerystės programa';
$_['text_special']                      = 'Akcijos';
$_['text_account']                      = 'Mano paskyra';
$_['text_order']                        = 'Užsakymo istorija';
$_['text_wishlist']                     = 'Pageidavimų sąrašas';
$_['text_newsletter']                   = 'Naujienlaiškiai';
$_['text_powered']                      = 'Naudoja <a href="http://www.opencart.com">OpenCart</a><br /> %s &copy; %s';
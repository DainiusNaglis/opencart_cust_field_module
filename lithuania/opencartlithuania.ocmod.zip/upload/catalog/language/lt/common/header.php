<?php
// Text
$_['text_home']                         = 'Pagrindinis';
$_['text_wishlist']                     = 'Pageidavimai (%s)';
$_['text_shopping_cart']                = 'Krepšelis';
$_['text_category']                     = 'Kategorijos';
$_['text_account']                      = 'Mano paskyra';
$_['text_register']                     = 'Registruotis';
$_['text_login']                        = 'Prisijungti';
$_['text_order']                        = 'Užsakymo istorija';
$_['text_transaction']                  = 'Sandoriai';
$_['text_download']                     = 'Atsisiuntimai';
$_['text_logout']                       = 'Atsijungti';
$_['text_checkout']                     = 'Atsiskaitymas';
$_['text_search']                       = 'Paieška';
$_['text_all']                          = 'Rodyti viską';
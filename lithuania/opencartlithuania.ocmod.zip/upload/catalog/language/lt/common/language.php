<?php
// Text
$_['text_language']                     = 'Kalba';

<?php
// Heading
$_['heading_title']                     = 'Tvarkymo darbai';

// Text
$_['text_maintenance']                  = 'Tvarkymo darbai';
$_['text_message']     = '<h1 style="text-align:center;">Šiuo metu atliekame numatytą techninę priežiūrą. <br/>Mes grįšime kaip įmanoma greičiau. Prašome patikrinkite vėliau.</h1>';
<?php
//heading

$_['heading_title'] = 'Login';

//Text

$_['text_extension'] = 'Extensions';
$_['text_success'] = 'Success: You have modified Custom Fields module!';
$_['text_edit'] = 'Add Custom Field';
//Entry
$_['entry_status'] = 'Status';
//Error
$_['error_permission'] = 'Warning: You do not have permission to modify Custom Fields module!';